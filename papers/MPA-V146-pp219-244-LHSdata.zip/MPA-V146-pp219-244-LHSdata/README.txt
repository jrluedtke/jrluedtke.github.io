This is the test instance data for the results reported in Tables 2-4, and the last four rows of Table 5, of the paper: 
- James Luedtke, "A branch-and-cut decomposition algorithm for solving chance-constrained mathematical programs with
  finite support'', Mathematical Programming, 146:219-244, 2014.

Specifically, these are the instances in which some of the constraint coefficients are random. An instance is specified by two
files: a `base' file, which speccifies the information about the instance that does not vary by scenario, and a
random points file, which specifies the scenario data. There are three ``base'' files
corresponding to the three base instances, and for each of these there are 5 ``randpts'' files corresponding to the 5
different scenario sets. For the 10 customer instances, the ``randpts'' files has 2000 scenarios. For the 20 and 30 customer
instances, the ``randpts'' files have 3000 senarios. Instances with N < 2000 (or 3000) scenarios are
obtained by taking the first N scenarios from the set of 2000 (or 3000) in the data file.

Format of the data in the ``base'' files.
- The file name is ``basen-m'', where n is an integer referring to the number of servers, and m is an integer referring
  to the number of customers (which is also the dimension of the random demand vector).
- In the file:
  - The number on first line is n: the number of server classes
  - The number on second line is m: the number of customer classes 
  - For each of the following m lines (one per customer): Array of service rates for that customer, if served by each
	 server (i.e., for customer row j, element i of this array is \mu_{ij}). The array format is [ \mu_j1, \mu_j2, ...
	 \mu_{jn}]. A number < 0 indicates that server is not able to serve that customer. 
  - The final line provides an array of costs per server (that data c_i, i=1,...,n) 

Format of the data in the ``randpts'' files.
- The file name is ``allrandpts-md-N-k'', where m is an integer representing the number of customers, N is an integer
  representing the total number of scenarios in the file, and k is an index for the instance (0,1,2,3,4).
- First row: Contains the character 'r' (used to indicate a file type)
- Next is a double array of the form [ [ #,... ,# ], [#,... ,# ], ..., [#,#,# ]]. This consists of N arrays, each of
  size m, representing the customer arrival counts in each of the N scenarios.
- Next is a double array containing N vectors, each of size n, representing the server proportion availibility
  scenarios.
- Finally, there is a triple array, containing N matrices, each of size m rows and n columns. The (i,j) entry of this
  matrix represents the amount by which \mu_{ij} is perturbed in that scenario. (These perturbations are just ignored for
  instances in which the server availability is random, bu the service rates are not random.)
