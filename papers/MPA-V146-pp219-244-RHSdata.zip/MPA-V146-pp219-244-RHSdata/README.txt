This is the test instance data for the results reported in Table 1, and the first two rows of Table 5, of the paper: 
- James Luedtke, "A branch-and-cut decomposition algorithm for solving chance-constrained mathematical programs with
  finite support'', Mathematical Programming, 146:219-244, 2014.

Specifically, these are the instances in which only the right-hand side is random. An instance is specified by two
files: a `basedata' file, which speccifies the information about the instance that does not vary by scenario, and a
random points file, which specifies the set of customer counts in each scenario. There are three ``base'' files
corresponding to the three base instances, and for each of these there are 5 ``randpts'' files corresponding to the 5
different scenario sets. Each of the ``randpts'' files has 3000 scenarios. Instances with N < 3000 scenarios are
obtained by taking the first N scenarios from the set of 3000 in the data file.

Format of the data in the ``base'' files.
- The file name is ``basen-m'', where n is an integer referring to the number of servers, and m is an integer referring
  to the number of customers (which is also the dimension of the random demand vector).
- In the file:
  - The number on first line is n: the number of server classes
  - The number on second line is m: the number of customer classes 
  - For each of the following m lines (one per customer): Array of service rates for that customer, if served by each
	 server (i.e., for customer row j, element i of this array is \mu_{ij}). The array format is [ \mu_j1, \mu_j2, ...
	 \mu_{jn}]. A service rate less than zero (-1, specifically) indicates that server is not able to serve that customer
	 type.
  - The final line provides an array of costs per server (that data c_i, i=1,...,n) 

Format of the data in the ``randpts'' files.
- The file name is ``randpts-md-3000-k'', where m is an integer representing the number of customers (size of data
  array in each scenario) and k is an index for the instance (0,1,2,3,4).
- The file consists of 3000 arrays, each representing the set of customer demands in a scenario. The format the kth array
  is [lambda_1^k, lambda_2^k, ..., lambda_m^k] (i.e., an array start is indicated by '[', there are then m numbers,
  seaparated by commas, and the end of the array is indicated by ']'.)
